"""Carrega as 20 reservas de teste. Uso: python seed.py  (usa o mesmo banco do app: defina DB_URL para Postgres)."""
import os
from sqlalchemy import create_engine, text
e = create_engine(os.environ.get("DB_URL", "sqlite:///reservas.db"))
CI, Z, C = "2026-11-06T14:00", "(11) 99999-0000", "529.982.247-25"
d = lambda a, b: (f"2026-11-{a:02d}", f"2026-11-{b:02d}")
T = [("Ferreira Francisco Santana Lorena","37",2,d(6,8),"Booking",1),("Felipe Orlandelli","57",2,d(5,8),"Airbnb",1),("Rafael Galleazzo Villela de Andrade","58",2,d(4,7),"Booking",1),
("Matheus Rech","62",3,d(6,8),"Booking",1),("Misael","64",4,d(6,10),"Direto",1),("Maria Clara Coutinho","65",3,d(6,9),"Airbnb",1),("Paula Virgínia Simões Fidelis","66",3,d(6,8),"Airbnb",1),
("Italo Joseph Alighiery dos Santos","23",1,d(5,9),"Direto",1),("Rafael Souza","72",1,d(5,8),"Airbnb",1),("Glenio Siqueira","75",1,d(6,9),"Airbnb",1),("João Victor Majuri","78",2,d(5,8),"Airbnb",1),
("Lauro Graziani da Cruz","81",2,d(6,8),"Airbnb",1),("Davy Jacinto de Castro","84",2,d(5,8),"Airbnb",1),("Enoque","87",2,d(6,8),"Direto",1),("Ivanielle e Marianna","88",2,d(4,7),"Airbnb",1),
("Leonardo Barbosa","52",1,d(9,13),"Airbnb",0),("Peter Douglas","",3,d(7,10),"Direto",0,"1C1S"),("Laura Lopes Ferreira","",2,d(7,9),"Direto",0),("Lauro Giacheti","",1,d(9,11),"Booking",0),
("Carlos Augusto Jorge Pagano","",3,("2026-11-16","2026-11-24"),"Airbnb",0)]
with e.begin() as c:
    for n, a, h, (i, f), o, ok, *cama in T:
        c.execute(text("INSERT INTO reservas(nome,apto,hosp,ini,fim,origem,cama,cpf,zap,cin) VALUES(:n,:a,:h,:i,:f,:o,:cm,:c,:z,:ci)"),
                  dict(n=n, a=a, h=h, i=i, f=f, o=o, cm=(cama or [""])[0], c=C if ok else None, z=Z if ok else None, ci=CI if ok else None))
print("20 reservas de teste gravadas")
